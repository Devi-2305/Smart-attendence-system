import csv
import os, cv2
import numpy as np
import pandas as pd
import datetime
import time
from PIL import ImageTk, Image


# Train Image
def TrainImage(haarcasecade_path, trainimage_path, trainimagelabel_path, message,text_to_speech):
    try:
        # Check if cv2.face module is available
        if not hasattr(cv2, 'face'):
            error_msg = "cv2.face module not found. Please install opencv-contrib-python: pip install opencv-contrib-python"
            message.configure(text=error_msg)
            text_to_speech(error_msg)
            return
        
        faces, Id = getImagesAndLables(trainimage_path)
        if not faces:
            t = "No training images found. Please register students and take images first."
            message.configure(text=t)
            text_to_speech(t)
            return
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        recognizer.train(faces, np.array(Id))
        recognizer.save(trainimagelabel_path)
        res = "Image Trained successfully"  # +",".join(str(f) for f in Id)
        message.configure(text=res)
        text_to_speech(res)
    except Exception as e:
        error_msg = f"Training failed: {str(e)}"
        message.configure(text=error_msg)
        text_to_speech(error_msg)


def getImagesAndLables(path):
    # imagePath = [os.path.join(path, f) for d in os.listdir(path) for f in d]
    if not os.path.exists(path) or not os.listdir(path):
        return [], []
    newdir = [os.path.join(path, d) for d in os.listdir(path) if os.path.isdir(os.path.join(path, d))]
    if not newdir:
        return [], []
    imagePath = [
        os.path.join(newdir[i], f)
        for i in range(len(newdir))
        for f in os.listdir(newdir[i])
        if f.lower().endswith(('.jpg', '.jpeg', '.png'))
    ]
    faces = []
    Ids = []
    for img_path in imagePath:
        try:
            pilImage = Image.open(img_path).convert("L")
            imageNp = np.array(pilImage, "uint8")
            Id = int(os.path.split(img_path)[-1].split("_")[1])
            faces.append(imageNp)
            Ids.append(Id)
        except Exception as e:
            print(f"Error processing {img_path}: {e}")
            continue
    return faces, Ids
