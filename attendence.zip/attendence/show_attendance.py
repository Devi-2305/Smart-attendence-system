import pandas as pd
from glob import glob
import os
import tkinter
import csv
import re
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import *


def is_valid_name(value):
    return bool(re.fullmatch(r"[A-Za-z ]+", value.strip()))


def extract_date_from_filename(filename):
    match = re.search(r"_(\d{4}-\d{2}-\d{2})_", os.path.basename(filename))
    return match.group(1) if match else None


def subjectchoose(text_to_speech):
    def calculate_attendance():
        Subject = tx.get().strip()
        if Subject == "":
            t='Please enter the subject name.'
            text_to_speech(t)
            return
        elif not is_valid_name(Subject):
            t='Subject name can only contain uppercase and lowercase letters and spaces.'
            text_to_speech(t)
            return
    
        # search using absolute attendance path
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Attendance")
        filenames = glob(os.path.join(base, Subject, f"{Subject}*.csv"))
        selected_date = date_var.get().strip()
        if selected_date and selected_date != "All Dates":
            filenames = [f for f in filenames if extract_date_from_filename(f) == selected_date]
        if not filenames:
            t = f"No attendance records found for subject '{Subject}'"
            if selected_date and selected_date != "All Dates":
                t = f"No attendance records found for subject '{Subject}' on date '{selected_date}'"
            text_to_speech(t)
            return
        df = [pd.read_csv(f) for f in filenames]
        newdf = df[0]
        for i in range(1, len(df)):
            newdf = newdf.merge(df[i], how="outer")
        newdf.fillna(0, inplace=True)
        newdf["Attendance"] = 0
        for i in range(len(newdf)):
            newdf["Attendance"].iloc[i] = str(int(round(newdf.iloc[i, 2:-1].mean() * 100)))+'%'
            #newdf.sort_values(by=['Enrollment'],inplace=True)
        # save merged attendance using absolute paths
        merged_path = os.path.join(base, Subject)
        os.makedirs(merged_path, exist_ok=True)
        merged_csv = os.path.join(merged_path, "attendance.csv")
        newdf.to_csv(merged_csv, index=False)

        root = tkinter.Tk()
        root.title("Attendance of "+Subject)
        root.configure(background="black")
        cs = merged_csv
        with open(cs) as file:
            reader = csv.reader(file)
            r = 0

            for col in reader:
                c = 0
                for row in col:

                    label = tkinter.Label(
                        root,
                        width=10,
                        height=1,
                        fg="yellow",
                        font=("times", 15, " bold "),
                        bg="black",
                        text=row,
                        relief=tkinter.RIDGE,
                    )
                    label.grid(row=r, column=c)
                    c += 1
                r += 1
        root.mainloop()
        print(newdf)

    subject = Tk()
    # windo.iconbitmap("AMS.ico")
    subject.title("Subject...")
    subject.geometry("580x320")
    subject.resizable(0, 0)
    subject.configure(background="black")
    # subject_logo = Image.open("UI_Image/0004.png")
    # subject_logo = subject_logo.resize((50, 47), Image.ANTIALIAS)
    # subject_logo1 = ImageTk.PhotoImage(subject_logo)
    titl = tk.Label(subject, bg="black", relief=RIDGE, bd=10, font=("arial", 30))
    titl.pack(fill=X)
    # l1 = tk.Label(subject, image=subject_logo1, bg="black",)
    # l1.place(x=100, y=10)
    titl = tk.Label(
        subject,
        text="Which Subject of Attendance?",
        bg="black",
        fg="green",
        font=("arial", 25),
    )
    titl.place(x=100, y=12)

    def Attf():
        sub = tx.get().strip()
        if sub == "":
            t="Please enter the subject name!!!"
            text_to_speech(t)
        elif not is_valid_name(sub):
            t='Subject name can only contain uppercase and lowercase letters and spaces.'
            text_to_speech(t)
        else:
            os.startfile(
            f"Attendance\\{sub}"
            )


    attf = tk.Button(
        subject,
        text="Check Sheets",
        command=Attf,
        bd=7,
        font=("times new roman", 15),
        bg="black",
        fg="yellow",
        height=2,
        width=10,
        relief=RIDGE,
    )
    attf.place(x=360, y=170)

    sub = tk.Label(
        subject,
        text="Enter Subject",
        width=10,
        height=2,
        bg="black",
        fg="yellow",
        bd=5,
        relief=RIDGE,
        font=("times new roman", 15),
    )
    sub.place(x=50, y=80)

    tx = tk.Entry(
        subject,
        width=15,
        bd=5,
        bg="black",
        fg="yellow",
        relief=RIDGE,
        font=("times", 30, "bold"),
    )
    tx.place(x=190, y=80)

    date_label = tk.Label(
        subject,
        text="Select Date",
        width=10,
        height=2,
        bg="black",
        fg="yellow",
        bd=5,
        relief=RIDGE,
        font=("times new roman", 15),
    )
    date_label.place(x=50, y=150)

    date_var = tk.StringVar()
    date_combo = ttk.Combobox(
        subject,
        textvariable=date_var,
        width=14,
        state="readonly",
        font=("times", 18, "bold"),
    )
    date_combo.place(x=190, y=155)

    def refresh_dates(*args):
        Subject = tx.get().strip()
        if Subject == "":
            date_combo["values"] = ["All Dates"]
            date_var.set("All Dates")
            return
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Attendance")
        filenames = glob(os.path.join(base, Subject, f"{Subject}*.csv"))
        dates = sorted({extract_date_from_filename(f) for f in filenames if extract_date_from_filename(f)})
        date_combo["values"] = ["All Dates"] + dates
        if date_var.get() not in date_combo["values"]:
            date_var.set("All Dates")

    tx.bind("<KeyRelease>", refresh_dates)
    refresh_dates()

    fill_a = tk.Button(
        subject,
        text="View Attendance",
        command=calculate_attendance,
        bd=7,
        font=("times new roman", 15),
        bg="black",
        fg="yellow",
        height=2,
        width=12,
        relief=RIDGE,
    )
    fill_a.place(x=195, y=220)
    subject.mainloop()
