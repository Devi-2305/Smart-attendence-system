import csv
import os, cv2
import re
import numpy as np
import pandas as pd
import datetime
import time




def is_valid_name(value):
    return bool(re.fullmatch(r"[A-Za-z ]+", value.strip()))


def is_student_already_registered(enrollment, name, csv_path):
    if not os.path.exists(csv_path):
        return False

    try:
        with open(csv_path, newline="", encoding="utf-8") as csvFile:
            rows = list(csv.reader(csvFile))
    except Exception:
        return False

    enrollment_key = str(enrollment).strip().lower()
    name_key = str(name).strip().lower()

    for row in rows:
        if not row:
            continue
        if len(row) < 2:
            continue
        stored_enrollment = str(row[0]).strip().lower()
        stored_name = str(row[1]).strip().lower()
        if stored_enrollment == enrollment_key or (
            stored_name == name_key and stored_enrollment == enrollment_key
        ):
            return True

    return False


# take Image of user
def TakeImage(l1, l2, haarcasecade_path, trainimage_path, message, err_screen,text_to_speech):
    if (l1 == "") and (l2==""):
        t='Please Enter the your Enrollment Number and Name.'
        text_to_speech(t)
    elif l1=='':
        t='Please Enter the your Enrollment Number.'
        text_to_speech(t)
    elif l2 == "":
        t='Please Enter the your Name.'
        text_to_speech(t)
    elif not is_valid_name(l2):
        t='Name can only contain uppercase and lowercase letters and spaces.'
        text_to_speech(t)
    else:
        try:
            cam = cv2.VideoCapture(0)
            if not os.path.exists(haarcasecade_path):
                text_to_speech(f"Cascade file not found: {haarcasecade_path}")
                return
            detector = cv2.CascadeClassifier(haarcasecade_path)
            if detector.empty():
                text_to_speech("Failed to load Haar cascade classifier")
                return
            Enrollment = l1
            Name = l2
            sampleNum = 0
            script_dir = os.path.dirname(os.path.abspath(__file__))
            csv_path = os.path.join(script_dir, "StudentDetails", "studentdetails.csv")

            if is_student_already_registered(Enrollment, Name, csv_path):
                msg = "Student is already registered."
                message.configure(text=msg)
                text_to_speech(msg)
                return

            directory = Enrollment + "_" + Name
            path = os.path.join(trainimage_path, directory)
            if os.path.exists(path):
                msg = "Student is already registered."
                message.configure(text=msg)
                text_to_speech(msg)
                return
            os.mkdir(path)
            while True:
                ret, img = cam.read()
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = detector.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    sampleNum = sampleNum + 1
                    # construct filename in a safe cross-platform way
                    filename = (
                        Name
                        + "_"
                        + Enrollment
                        + "_"
                        + str(sampleNum)
                        + ".jpg"
                    )
                    full_path = os.path.join(path, filename)
                    cv2.imwrite(full_path, gray[y : y + h, x : x + w])
                    cv2.imshow("Frame", img)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
                elif sampleNum > 50:
                    break
            cam.release()
            cv2.destroyAllWindows()
            row = [Enrollment, Name]
            with open(
                csv_path,
                "a+",
            ) as csvFile:
                writer = csv.writer(csvFile, delimiter=",")
                writer.writerow(row)
                csvFile.close()
            res = "Images Saved for ER No:" + Enrollment + " Name:" + Name
            message.configure(text=res)
            text_to_speech(res)
        except FileExistsError as F:
            F = "Student Data already exists"
            text_to_speech(F)
